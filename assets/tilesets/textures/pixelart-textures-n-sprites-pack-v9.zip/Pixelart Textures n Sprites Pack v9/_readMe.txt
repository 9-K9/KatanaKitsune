Thank You for purchasing this textures package!
--------------------------------------------------
I'm still working on it so if You have any suggestions, topics that should be included/painted - feel free to share.


License:
-------------
What You can do:
- You can use the assets for commercial or personal projects.
- Edit the assets freely depends on Your needs.

What You can't do:
- Resell, repackage or redistribute in original or modified form.


Changelog:
-------------

2024.03.12:
- 284 textures, 45 sprites, 12 particle textures, 12 skydomes, 12 spritesheets, 12 debug textures
- "_detectors" folder renamed to "_debug"
- Some textures fixed
Total: 377 files

2024.02.05:
- 267 textures, 42 sprites, 12 particle textures, 9 skydomes, 10 spritesheets, 10 detectors
- Added "_detectors" folder
Total: 340 files

2023.08.22:
- 253 textures, 36 sprites, 9 particle textures, 8 skydomes, 9 spritesheets
Total: 315 files

2023.07.07:
- 228 textures, 33 sprites, 9 particle textures, 8 skydomes, 9 spritesheets
Total: 287 files

2023.05.27:
- 217 textures, 21 sprites, 9 particle textures, 8 skydomes, 8 spritesheets
- Street texture fixes + added new
- Single objects + some new ones moved to "_sprites" folder
Total: 263 files

2023.04.27:
- 225 texture files, 9 particle textures, 8 skydomes, 8 spritesheets
Total: 250 files

2023.03.13:
- 206 texture files, 9 particle textures, 8 skydomes, 5 spritesheets
- Added "_spritesheets" folder
- Added "_skydomes" folder
- Added "_particles" folder
Total: 228 files

2023.02.10: 
- Added 33 new textures + texture fixes



Hope You'll enjoy this pack!
Bitmap Impact


-------------------------

If You like my work, You can support me on Patreon page:
https://www.patreon.com/bitmapimpact